<img src="{{ asset('images/logo.png') }}" alt="شعار الموقع" class="h-16 w-auto">
